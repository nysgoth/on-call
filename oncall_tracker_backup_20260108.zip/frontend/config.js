const API_BASE_URL = "http://localhost:8000";
if (typeof window !== "undefined") {
    window.API_BASE_URL = API_BASE_URL;
}
