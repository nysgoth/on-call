#!/usr/bin/env python3
"""
Demo script to generate sample incidents for the last month
Can be run multiple times - will skip dates that already have incidents
"""

import os
import sys
from datetime import datetime, timedelta
import random
import uuid

# Add the app directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.database import SessionLocal, engine
from app import models
from sqlalchemy import func

# Sample data
INCIDENT_TYPES = ['Outage', 'Degradation', 'Other']
PRIORITIES = [1, 2, 3, 4]  # Critical, High, Medium, Low
PRIORITY_WEIGHTS = [0.1, 0.2, 0.4, 0.3]  # Lower probability for Critical, higher for Medium/Low

SAMPLE_DESCRIPTIONS = [
    "Database connection timeout during peak hours - Multiple connection pool exhaustion events detected between 14:00-16:00. Application servers unable to establish new database connections, causing transaction failures.",
    "High CPU usage on application servers - CPU utilization reached 95% on 3 out of 5 application servers. Investigation revealed inefficient query patterns in reporting module causing excessive load.",
    "Network latency spike affecting user experience - Users reported slow response times. Network monitoring showed 200ms latency increase on primary data center connection. Packet loss detected at 0.5%.",
    "SSL certificate expiration warning - SSL certificate for api.dskbank.bg expiring in 7 days. Automated renewal process failed due to DNS configuration issue. Manual intervention required.",
    "Memory leak detected in background service - Background job processor showing continuous memory growth from 2GB to 8GB over 24 hours. Heap dump analysis revealed unclosed database connections in batch processing module.",
    "API rate limiting triggered unexpectedly - Third-party payment gateway API started returning 429 errors. Investigation showed our rate limit configuration was too aggressive for peak transaction volumes.",
    "Disk space running low on backup server - Backup storage server reached 85% capacity. Automated cleanup scripts failed to run due to permission issues. Manual cleanup required to free 500GB space.",
    "Failed scheduled backup job - Nightly database backup job failed with 'insufficient disk space' error. Backup retention policy not properly configured, causing accumulation of old backup files.",
    "Authentication service intermittent failures - Users experiencing random login failures. Log analysis showed authentication service restarting every 2-3 hours due to memory pressure. Service restarting automatically but causing brief outages.",
    "Load balancer health check failures - Load balancer marked 2 out of 5 application servers as unhealthy. Health check endpoint returning 503 errors intermittently. Root cause: database connection pool exhaustion on affected servers.",
    "Cache invalidation causing slow responses - Cache invalidation strategy too aggressive, causing cache hit rate to drop from 85% to 45%. Application performance degraded significantly as more requests hit database directly.",
    "Third-party API timeout issues - Integration with external banking API experiencing 30-second timeouts. External service status page shows degraded performance. Implemented retry logic with exponential backoff.",
    "Database query performance degradation - Critical reporting query execution time increased from 2 seconds to 45 seconds. Query plan analysis revealed missing index on transaction_date column. Index creation in progress.",
    "CDN cache miss rate increased - CDN cache hit rate dropped from 92% to 68%. Investigation showed cache headers not properly set on new API endpoints. Updated cache configuration for affected endpoints.",
    "Message queue backlog accumulation - Message queue processing lag increased to 2 hours. Consumer service running at reduced capacity due to memory issues. Scaled up consumer instances and resolved memory leak.",
    "Session storage connection pool exhausted - Redis session storage connection pool reached maximum connections (100). Investigation revealed connection leaks in session management middleware. Fixed connection cleanup logic.",
    "Log aggregation service lagging - Log aggregation service processing delay increased to 15 minutes. High volume of debug logs from new feature causing processing bottleneck. Adjusted log levels and increased processing capacity.",
    "Monitoring alert false positive - Disk usage alert triggered incorrectly due to temporary file accumulation. Monitoring script not accounting for temporary files in calculation. Updated monitoring logic.",
    "Scheduled maintenance window - Planned maintenance for database server upgrade. All services running in read-only mode. Expected downtime: 2 hours. All stakeholders notified in advance.",
    "Configuration deployment issue - New configuration deployment caused application startup failures on 2 servers. Configuration validation not catching invalid values. Rolled back configuration and fixed validation logic.",
    "Payment gateway integration timeout - Payment processing service experiencing intermittent timeouts when communicating with external payment gateway. Timeout set to 10 seconds but gateway sometimes takes 15-20 seconds to respond. Increased timeout and added retry mechanism.",
    "Database replication lag - Read replica database showing 5-minute replication lag. Primary database under heavy write load. Replication process unable to keep up. Temporarily increased replication buffer size.",
    "SSL handshake failures - Some clients experiencing SSL handshake failures with error 'handshake timeout'. Investigation revealed TLS 1.0 clients trying to connect but server only supports TLS 1.2+. Updated client configuration.",
    "Memory pressure on application servers - Application servers showing high memory usage (85%+) causing OOM killer to terminate processes. Heap analysis showed memory leak in image processing module. Fixed memory leak and restarted services.",
    "Database deadlock detected - Multiple deadlocks detected in transaction processing. Deadlock graph analysis showed circular dependency in account update operations. Optimized transaction isolation levels and query order."
]

SAMPLE_RESOLUTIONS = [
    "Restarted affected services and resolved - Restarted application servers and database connection pool. All services recovered and connection pool stabilized. Monitoring shows normal operation.",
    "Increased resource allocation - Increased CPU and memory allocation for affected servers. CPU usage normalized to 60-70% range. Performance metrics back to baseline.",
    "Applied hotfix patch - Deployed hotfix patch that addresses the root cause. Patch includes connection pool optimization and query performance improvements. All systems operational.",
    "Rolled back problematic deployment - Identified problematic deployment and rolled back to previous stable version. System restored to normal operation. Root cause analysis scheduled.",
    "Updated configuration and restarted - Updated application configuration with optimized settings. Restarted all affected services. Configuration changes verified and system stable.",
    "Cleared cache and restarted services - Cleared application cache and Redis cache. Restarted cache service and application servers. Cache hit rate restored to normal levels.",
    "Fixed database connection pool settings - Updated connection pool configuration: increased max connections from 50 to 100, adjusted timeout settings. Connection pool now operating within normal parameters.",
    "Resolved by scaling up resources - Scaled up application servers from 3 to 5 instances. Load distributed evenly across all instances. Response times improved significantly.",
    "Applied security patch - Applied critical security patch addressing vulnerability. Patch tested in staging environment before production deployment. All systems patched and verified.",
    "Fixed by updating dependencies - Updated problematic library to latest stable version. Dependency update resolved compatibility issues. All tests passing and system operational.",
    "Resolved network routing issue - Updated network routing configuration to use optimal path. Network latency reduced from 200ms to 50ms. All network metrics normal.",
    "Cleared stuck processes - Identified and terminated stuck background processes. Process monitoring shows all services running normally. No further stuck processes detected.",
    "Updated firewall rules - Updated firewall rules to allow necessary traffic. Connectivity restored and all services accessible. Security audit completed.",
    "Resolved DNS resolution issue - Fixed DNS configuration causing resolution failures. DNS queries now resolving correctly. All services can reach external dependencies.",
    "Fixed by restarting service cluster - Performed rolling restart of entire service cluster. All services recovered and operating normally. No data loss during restart process.",
    "Created missing database index - Created index on transaction_date column. Query performance improved from 45 seconds to 2 seconds. Database performance metrics normalized.",
    "Updated cache headers - Added proper cache headers to new API endpoints. CDN cache hit rate restored to 92%. Response times improved for cached content.",
    "Scaled up consumer instances - Increased message queue consumer instances from 2 to 5. Message processing lag reduced from 2 hours to 5 minutes. Queue backlog cleared.",
    "Fixed connection cleanup logic - Updated session management middleware to properly close Redis connections. Connection pool usage normalized. No more connection leaks detected.",
    "Adjusted log levels - Reduced debug logging for new feature. Log volume decreased by 60%. Log aggregation service processing delay reduced to normal levels.",
    "Increased timeout and added retry - Increased payment gateway timeout to 30 seconds and implemented exponential backoff retry (3 attempts). Payment processing success rate improved to 99.5%.",
    "Increased replication buffer - Temporarily increased replication buffer size to handle peak write load. Replication lag reduced to under 1 minute. Monitoring replication metrics.",
    "Optimized transaction isolation - Changed transaction isolation level from SERIALIZABLE to READ COMMITTED for account updates. Deadlock frequency reduced by 90%. Transaction processing normalized."
]

# Get engineers from database
def get_engineers(db):
    """Get list of engineer usernames"""
    engineers = db.query(models.User).filter(models.User.role == 'engineer').all()
    if not engineers:
        # Fallback to default if no engineers found
        return ['engineer1']
    return [user.username for user in engineers]

def incident_exists_for_date(db, date):
    """Check if an incident already exists for a given date"""
    start_of_day = datetime.combine(date, datetime.min.time())
    end_of_day = datetime.combine(date, datetime.max.time())
    
    count = db.query(models.Incident).filter(
        models.Incident.incident_start >= start_of_day,
        models.Incident.incident_start < end_of_day
    ).count()
    
    return count > 0

def generate_incident_for_date(db, date, engineer):
    """Generate a single incident for a given date"""
    # Random time during the day (between 8 AM and 8 PM)
    hour = random.randint(8, 20)
    minute = random.randint(0, 59)
    incident_start = datetime.combine(date, datetime.min.time().replace(hour=hour, minute=minute))
    
    # 85% chance of having an end time (resolved)
    has_end = random.random() < 0.85
    if has_end:
        # End time between 15 minutes and 6 hours later (longer for more realistic scenarios)
        duration_minutes = random.randint(15, 360)
        incident_end = incident_start + timedelta(minutes=duration_minutes)
    else:
        incident_end = None
    
    # Random priority with weighted distribution
    priority = random.choices(PRIORITIES, weights=PRIORITY_WEIGHTS)[0]
    
    # Random incident type
    incident_type = random.choice(INCIDENT_TYPES)
    
    # Random description and resolution - prefer longer, more detailed ones
    description = random.choice(SAMPLE_DESCRIPTIONS)
    # If incident is resolved, use detailed resolution
    resolution = random.choice(SAMPLE_RESOLUTIONS) if has_end else None
    
    # Create incident
    incident = models.Incident(
        incident_start=incident_start,
        incident_end=incident_end,
        on_call_engineer=engineer,
        incident_type=incident_type,
        severity=priority,
        description=description,
        resolution=resolution,
        manager_reviewed=random.random() < 0.6  # 60% chance of being reviewed
    )
    
    if incident.manager_reviewed:
        # Set review timestamp (between incident start and now)
        review_delay_hours = random.randint(1, 48)
        incident.manager_reviewed_at = incident_start + timedelta(hours=review_delay_hours)
        # Random manager name
        managers = db.query(models.User).filter(models.User.role.in_(['manager', 'admin'])).all()
        if managers:
            incident.manager_name = random.choice(managers).username
        else:
            incident.manager_name = 'manager1'
    
    return incident

def main():
    """Main function to generate demo incidents"""
    print("🚀 Starting demo incident generation...")
    
    db = SessionLocal()
    
    try:
        # Get engineers
        engineers = get_engineers(db)
        if not engineers:
            print("❌ No engineers found in database. Please run init_db.py first.")
            return
        
        print(f"📋 Found {len(engineers)} engineer(s): {', '.join(engineers)}")
        
        # Calculate date range (last 30 days)
        today = datetime.now().date()
        start_date = today - timedelta(days=30)
        
        print(f"📅 Generating incidents from {start_date} to {today}")
        
        created_count = 0
        skipped_count = 0
        
        # Generate incidents - multiple per day for more variety
        current_date = start_date
        while current_date <= today:
            # Generate 1-3 incidents per day (random, weighted towards 1-2)
            incidents_per_day = random.choices([1, 2, 3], weights=[0.5, 0.35, 0.15])[0]
            
            for i in range(incidents_per_day):
                # Check if we should skip (only check first incident of the day)
                if i == 0 and incident_exists_for_date(db, current_date):
                    print(f"⏭️  Skipping {current_date} - incident already exists")
                    skipped_count += 1
                    break
                
                # Random engineer for this incident
                engineer = random.choice(engineers)
                
                # Generate incident
                incident = generate_incident_for_date(db, current_date, engineer)
                db.add(incident)
                db.commit()
                db.refresh(incident)
                
                priority_label = {1: 'Critical', 2: 'High', 3: 'Medium', 4: 'Low'}[incident.severity]
                status = "✅ Reviewed" if incident.manager_reviewed else "⏳ Not reviewed"
                
                print(f"✅ Created incident for {current_date}: {incident.incident_type} - {priority_label} - {status} ({engineer})")
                created_count += 1
            
            # Move to next day
            current_date += timedelta(days=1)
        
        print("\n" + "="*60)
        print(f"✨ Summary:")
        print(f"   Created: {created_count} new incidents")
        print(f"   Skipped: {skipped_count} dates (already have incidents)")
        print(f"   Total dates processed: {created_count + skipped_count}")
        print("="*60)
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    main()

