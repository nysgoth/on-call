"""
Initialize database with sample users
Run this script to create initial users for testing
"""

from app.database import SessionLocal, engine
from app import models
from app.auth import get_password_hash

# Create tables
models.Base.metadata.create_all(bind=engine)

db = SessionLocal()

# Create sample users
users = [
    {
        "username": "engineer1",
        "email": "engineer1@company.com",
        "role": "engineer",
        "password": "engineer123"
    },
    {
        "username": "engineer2",
        "email": "engineer2@company.com",
        "role": "engineer",
        "password": "engineer123"
    },
    {
        "username": "manager1",
        "email": "manager1@company.com",
        "role": "manager",
        "password": "manager123"
    },
    {
        "username": "admin1",
        "email": "admin1@company.com",
        "role": "admin",
        "password": "admin123"
    }
]

print("Creating sample users...")
for user_data in users:
    existing_user = db.query(models.User).filter(models.User.username == user_data["username"]).first()
    if not existing_user:
        user = models.User(
            username=user_data["username"],
            email=user_data["email"],
            role=user_data["role"],
            password_hash=get_password_hash(user_data["password"])
        )
        db.add(user)
        print(f"Created user: {user_data['username']} ({user_data['role']})")
    else:
        print(f"User already exists: {user_data['username']}")

db.commit()
db.close()
print("\nDatabase initialization complete!")
print("\nSample credentials:")
print("Engineer: engineer1 / engineer123")
print("Manager: manager1 / manager123")
print("Admin: admin1 / admin123")

