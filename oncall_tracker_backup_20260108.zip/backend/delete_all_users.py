#!/usr/bin/env python3
"""
Script to delete all users from the database
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.database import SessionLocal
from app import models

db = SessionLocal()

try:
    print("Deleting all users...")
    
    # Get all users
    users = db.query(models.User).all()
    print(f"Found {len(users)} users to delete")
    
    # Delete all users
    for user in users:
        print(f"Deleting user: {user.username} ({user.role})")
        db.delete(user)
    
    db.commit()
    print(f"\n✅ Successfully deleted {len(users)} users!")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
    db.rollback()
finally:
    db.close()

