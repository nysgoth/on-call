"""
Database models
"""

from sqlalchemy import Column, String, Integer, Boolean, DateTime, Text, ForeignKey, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid

from app.database import Base


class User(Base):
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String(255), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    first_name = Column(String(255), nullable=True)
    last_name = Column(String(255), nullable=True)
    role = Column(String(50), nullable=False)  # engineer, manager, admin
    password_hash = Column(String(255))  # For authentication
    approved = Column(Boolean, default=False)  # Admin approval required
    created_at = Column(DateTime, default=datetime.utcnow)


class Incident(Base):
    __tablename__ = "incidents"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    incident_start = Column(DateTime, nullable=False)
    incident_end = Column(DateTime)
    on_call_engineer = Column(String(255), nullable=False)
    incident_type = Column(String(100), nullable=False)
    severity = Column(Integer)  # 1-4 (1=Critical, 2=High, 3=Medium, 4=Low)
    description = Column(Text, nullable=False)
    resolution = Column(Text)
    manager_reviewed = Column(Boolean, default=False)
    manager_reviewed_at = Column(DateTime)
    manager_name = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship to audit log
    audit_logs = relationship("IncidentAuditLog", back_populates="incident", cascade="all, delete-orphan")


class IncidentAuditLog(Base):
    __tablename__ = "incident_audit_log"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    incident_id = Column(UUID(as_uuid=True), ForeignKey("incidents.id", ondelete="CASCADE"), nullable=False)
    action = Column(String(50), nullable=False)  # CREATE, UPDATE, DELETE, REVIEW
    changed_by = Column(String(255), nullable=False)
    changed_at = Column(DateTime, default=datetime.utcnow)
    old_values = Column(JSON)
    new_values = Column(JSON)
    
    # Relationship to incident
    incident = relationship("Incident", back_populates="audit_logs")


class PasswordResetRequest(Base):
    __tablename__ = "password_reset_requests"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    new_password_hash = Column(String(255), nullable=False)  # Hashed new password
    status = Column(String(50), default="pending")  # pending, approved, rejected
    requested_at = Column(DateTime, default=datetime.utcnow)
    reviewed_at = Column(DateTime)
    reviewed_by = Column(String(255))  # Admin username who reviewed
    
    # Relationship to user
    user = relationship("User")

