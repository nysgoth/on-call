"""
Pydantic schemas for request/response validation
"""

from pydantic import BaseModel, Field, EmailStr
from typing import Optional, List
from datetime import datetime, date
from uuid import UUID


class IncidentBase(BaseModel):
    incident_start: datetime
    incident_end: Optional[datetime] = None
    on_call_engineer: str
    incident_type: str
    severity: Optional[int] = Field(None, ge=1, le=4)
    description: str
    resolution: Optional[str] = None


class IncidentCreate(IncidentBase):
    pass


class IncidentUpdate(BaseModel):
    incident_start: Optional[datetime] = None
    incident_end: Optional[datetime] = None
    incident_type: Optional[str] = None
    severity: Optional[int] = Field(None, ge=1, le=4)
    description: Optional[str] = None
    resolution: Optional[str] = None


class IncidentResponse(IncidentBase):
    id: UUID
    manager_reviewed: bool
    manager_reviewed_at: Optional[datetime]
    manager_name: Optional[str]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class IncidentReview(BaseModel):
    reviewed: bool


class IncidentListResponse(BaseModel):
    items: List[IncidentResponse]
    total: int
    skip: int
    limit: int


class AuditLogResponse(BaseModel):
    id: UUID
    incident_id: UUID
    action: str
    changed_by: str
    changed_at: datetime
    old_values: Optional[dict]
    new_values: Optional[dict]
    
    class Config:
        from_attributes = True


class LoginRequest(BaseModel):
    username: str
    password: str


class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(..., min_length=6)
    first_name: str = Field(..., min_length=1, max_length=255)
    last_name: str = Field(..., min_length=1, max_length=255)
    role: str = Field(default="engineer", pattern="^(engineer|manager|admin)$")


class UserResponse(BaseModel):
    id: UUID
    username: str
    email: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    role: str
    approved: bool
    created_at: datetime
    
    class Config:
        from_attributes = True


class UserApprovalRequest(BaseModel):
    approved: bool


class UserUpdate(BaseModel):
    username: Optional[str] = Field(None, min_length=3, max_length=50)
    email: Optional[EmailStr] = None
    first_name: Optional[str] = Field(None, min_length=1, max_length=255)
    last_name: Optional[str] = Field(None, min_length=1, max_length=255)
    role: Optional[str] = Field(None, pattern="^(engineer|manager|admin)$")
    approved: Optional[bool] = None
    password: Optional[str] = Field(None, min_length=6)


class PasswordResetRequestCreate(BaseModel):
    email: EmailStr
    new_password: str = Field(..., min_length=6)


class PasswordResetRequestResponse(BaseModel):
    id: UUID
    user_id: UUID
    username: str
    email: str
    status: str
    requested_at: datetime
    reviewed_at: Optional[datetime]
    reviewed_by: Optional[str]
    
    class Config:
        from_attributes = True


class PasswordResetRequestReview(BaseModel):
    approved: bool


class DashboardStats(BaseModel):
    total_incidents: int
    pending_review: int
    by_priority: dict
    by_type: dict
    avg_resolution_time_hours: Optional[float]
    top_engineers: List[dict]
    incidents_by_day: List[dict]
    engineer_time_totals: List[dict]  # Engineer name, total_hours, total_incidents


class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse

