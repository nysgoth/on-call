"""
Authentication and authorization utilities
"""

import os
import logging
import traceback
from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from app import models

logger = logging.getLogger(__name__)

# JWT settings
SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 hours

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash"""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """Hash a password"""
    return pwd_context.hash(password)


def create_access_token(user: models.User) -> str:
    """Create JWT access token"""
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode = {
        "sub": user.username,
        "role": user.role,
        "exp": expire
    }
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def verify_token(token: str, db: Session) -> Optional[models.User]:
    """Verify JWT token and return user"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            logger.warning("Token payload missing 'sub' field")
            return None
    except JWTError as e:
        logger.warning(f"JWT verification failed: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error verifying token: {str(e)}\n{traceback.format_exc()}")
        return None
    
    try:
        user = db.query(models.User).filter(models.User.username == username).first()
        if not user:
            logger.warning(f"User {username} not found in database")
        return user
    except SQLAlchemyError as e:
        logger.error(f"Database error verifying token: {str(e)}\n{traceback.format_exc()}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error querying user: {str(e)}\n{traceback.format_exc()}")
        return None


def authenticate_user(db: Session, username: str, password: str) -> Optional[models.User]:
    """Authenticate user with username and password.
    Returns the user if authentication is successful, None otherwise.
    Does not check approval status - that should be checked separately.
    """
    try:
        user = db.query(models.User).filter(models.User.username == username).first()
        if not user:
            logger.debug(f"User {username} not found")
            return None
        
        # For demo purposes, if password_hash is None, accept any password
        # In production, always verify password
        if user.password_hash:
            try:
                if not verify_password(password, user.password_hash):
                    logger.debug(f"Invalid password for user {username}")
                    return None
            except Exception as e:
                logger.error(f"Error verifying password for user {username}: {str(e)}")
                return None
        
        logger.debug(f"User {username} authenticated successfully (password verified)")
        return user
    except SQLAlchemyError as e:
        logger.error(f"Database error authenticating user: {str(e)}\n{traceback.format_exc()}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error authenticating user: {str(e)}\n{traceback.format_exc()}")
        return None


def create_audit_log(
    db: Session,
    incident_id,
    action: str,
    changed_by: str,
    old_values: Optional[dict],
    new_values: Optional[dict]
):
    """Create an audit log entry"""
    try:
        import json
        from datetime import datetime
        
        # Convert datetime objects to strings for JSON serialization
        def serialize_datetime(obj):
            if isinstance(obj, datetime):
                return obj.isoformat()
            return obj
        
        # Serialize old_values and new_values
        serialized_old = None
        serialized_new = None
        
        try:
            if old_values:
                serialized_old = json.loads(json.dumps(old_values, default=serialize_datetime))
            if new_values:
                serialized_new = json.loads(json.dumps(new_values, default=serialize_datetime))
        except (TypeError, ValueError) as e:
            logger.warning(f"Error serializing audit log values: {str(e)}")
            # Continue with None values if serialization fails
        
        audit_log = models.IncidentAuditLog(
            incident_id=incident_id,
            action=action,
            changed_by=changed_by,
            old_values=serialized_old,
            new_values=serialized_new
        )
        db.add(audit_log)
        db.commit()
        logger.debug(f"Audit log created: {action} for incident {incident_id} by {changed_by}")
    except SQLAlchemyError as e:
        logger.error(f"Database error creating audit log: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise
    except Exception as e:
        logger.error(f"Unexpected error creating audit log: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise

