"""
On-Call Tracker API
FastAPI backend for tracking on-call incidents
"""

import logging
import traceback
import os
from fastapi import FastAPI, Depends, HTTPException, status, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import or_, func, extract
from typing import Optional, List
from datetime import datetime, date, timedelta
import uuid

from app.database import get_db, engine
from app import models, schemas, auth
from app.database import Base

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="On-Call Tracker API",
    description="API for tracking on-call incidents",
    version="1.0.0"
)

# CORS middleware
# Get allowed origins from environment variable, default to * for development
cors_origins = os.getenv("CORS_ORIGINS", "*")
if cors_origins == "*":
    allowed_origins = ["*"]
else:
    # Split by comma and strip whitespace
    allowed_origins = [origin.strip() for origin in cors_origins.split(",")]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBearer()


# Helper function to convert User model to UserResponse schema safely
def user_to_response(user: models.User) -> schemas.UserResponse:
    """Convert User model to UserResponse schema, handling optional fields"""
    return schemas.UserResponse(
        id=user.id,
        username=user.username,
        email=user.email,
        first_name=getattr(user, 'first_name', None),
        last_name=getattr(user, 'last_name', None),
        role=user.role,
        approved=user.approved,
        created_at=user.created_at
    )


# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handle all unhandled exceptions"""
    logger.error(
        f"Unhandled exception: {type(exc).__name__}: {str(exc)}\n"
        f"Path: {request.url.path}\n"
        f"Traceback: {traceback.format_exc()}"
    )
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error",
            "error_type": type(exc).__name__
        }
    )


@app.exception_handler(SQLAlchemyError)
async def sqlalchemy_exception_handler(request: Request, exc: SQLAlchemyError):
    """Handle database errors"""
    logger.error(
        f"Database error: {type(exc).__name__}: {str(exc)}\n"
        f"Path: {request.url.path}\n"
        f"Traceback: {traceback.format_exc()}"
    )
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Database error occurred",
            "error_type": type(exc).__name__
        }
    )


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
):
    """Get current authenticated user"""
    try:
        token = credentials.credentials
        logger.debug(f"Verifying token for user authentication")
        user = auth.verify_token(token, db)
        if not user:
            logger.warning("Invalid authentication token provided")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials"
            )
        logger.debug(f"User authenticated: {user.username} ({user.role})")
        return user
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in get_current_user: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Authentication error"
        )


@app.get("/")
async def root():
    return {
        "message": "On-Call Tracker API",
        "version": "1.0.0",
        "docs": "/docs"
    }


@app.post("/incidents", response_model=schemas.IncidentResponse, status_code=status.HTTP_201_CREATED)
async def create_incident(
    incident: schemas.IncidentCreate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new incident"""
    try:
        logger.info(f"Creating incident by user: {current_user.username}")
        db_incident = models.Incident(
            incident_start=incident.incident_start,
            incident_end=incident.incident_end,
            on_call_engineer=incident.on_call_engineer,
            incident_type=incident.incident_type,
            severity=incident.severity,
            description=incident.description,
            resolution=incident.resolution
        )
        
        db.add(db_incident)
        db.commit()
        db.refresh(db_incident)
        
        logger.info(f"Incident created successfully: {db_incident.id}")
        
        # Create audit log entry
        try:
            incident_dict = incident.model_dump(mode='json')
            auth.create_audit_log(db, db_incident.id, "CREATE", current_user.username, None, incident_dict)
        except Exception as audit_error:
            logger.error(f"Failed to create audit log: {str(audit_error)}")
            # Don't fail the request if audit log fails
        
        return db_incident
    except IntegrityError as e:
        logger.error(f"Database integrity error creating incident: {str(e)}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Database integrity error"
        )
    except SQLAlchemyError as e:
        logger.error(f"Database error creating incident: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error creating incident: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.get("/incidents", response_model=schemas.IncidentListResponse)
async def list_incidents(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    date_from: Optional[date] = Query(None, alias="date_from"),
    date_to: Optional[date] = Query(None, alias="date_to"),
    on_call_engineer: Optional[str] = Query(None),
    manager_reviewed: Optional[bool] = Query(None),
    severity: Optional[int] = Query(None, ge=1, le=4),
    incident_type: Optional[str] = Query(None, alias="incident_type"),
    search_text: Optional[str] = Query(None, alias="search_text"),
    sort_by: str = Query("incident_start", regex="^(incident_start|created_at|severity)$"),
    sort_order: str = Query("desc", regex="^(asc|desc)$"),
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List incidents with filtering and pagination"""
    try:
        logger.info(f"Listing incidents for user: {current_user.username}, filters: engineer={on_call_engineer}, reviewed={manager_reviewed}, search={search_text}")
        query = db.query(models.Incident)
        
        # Apply filters
        if date_from:
            query = query.filter(models.Incident.incident_start >= datetime.combine(date_from, datetime.min.time()))
        if date_to:
            query = query.filter(models.Incident.incident_start <= datetime.combine(date_to, datetime.max.time()))
        if on_call_engineer:
            query = query.filter(models.Incident.on_call_engineer.ilike(f"%{on_call_engineer}%"))
        if manager_reviewed is not None:
            query = query.filter(models.Incident.manager_reviewed == manager_reviewed)
        if severity:
            query = query.filter(models.Incident.severity == severity)
        if incident_type:
            query = query.filter(models.Incident.incident_type == incident_type)
        if search_text:
            # Search in description and resolution fields
            search_pattern = f"%{search_text}%"
            query = query.filter(
                or_(
                    models.Incident.description.ilike(search_pattern),
                    models.Incident.resolution.ilike(search_pattern)
                )
            )
        
        # Apply sorting
        try:
            sort_column = getattr(models.Incident, sort_by)
            if sort_order == "desc":
                query = query.order_by(sort_column.desc())
            else:
                query = query.order_by(sort_column.asc())
        except AttributeError:
            logger.warning(f"Invalid sort_by field: {sort_by}, using default")
            query = query.order_by(models.Incident.incident_start.desc())
        
        # Get total count
        total = query.count()
        
        # Apply pagination
        incidents = query.offset(skip).limit(limit).all()
        
        logger.info(f"Returning {len(incidents)} incidents (total: {total})")
        
        return {
            "items": incidents,
            "total": total,
            "skip": skip,
            "limit": limit
        }
    except SQLAlchemyError as e:
        logger.error(f"Database error listing incidents: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error listing incidents: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.get("/incidents/stats", response_model=schemas.DashboardStats)
async def get_incident_stats(
    date_from: Optional[date] = Query(None, alias="date_from"),
    date_to: Optional[date] = Query(None, alias="date_to"),
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get dashboard statistics for incidents (manager/admin only)"""
    try:
        if current_user.role not in ['manager', 'admin']:
            logger.warning(f"User {current_user.username} attempted to access stats without permission")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only managers and administrators can view statistics"
            )
        
        logger.info(f"Getting incident stats for user: {current_user.username}")
        
        # Base query
        query = db.query(models.Incident)
        
        # Apply date filters if provided
        if date_from:
            query = query.filter(models.Incident.incident_start >= datetime.combine(date_from, datetime.min.time()))
        if date_to:
            query = query.filter(models.Incident.incident_start <= datetime.combine(date_to, datetime.max.time()))
        
        # Total incidents
        total_incidents = query.count()
        
        # Pending review
        pending_review = query.filter(models.Incident.manager_reviewed == False).count()
        
        # By priority
        by_priority = {}
        for priority in [1, 2, 3, 4]:
            count = query.filter(models.Incident.severity == priority).count()
            priority_label = {1: "Critical", 2: "High", 3: "Medium", 4: "Low"}.get(priority, f"Priority {priority}")
            by_priority[priority_label] = count
        
        # By type
        by_type = {}
        incident_types = db.query(models.Incident.incident_type).distinct().all()
        for (incident_type,) in incident_types:
            if incident_type:
                count = query.filter(models.Incident.incident_type == incident_type).count()
                by_type[incident_type] = count
        
        # Average resolution time (in hours)
        avg_resolution_time_hours = None
        resolved_incidents = query.filter(
            models.Incident.incident_end.isnot(None),
            models.Incident.incident_start.isnot(None)
        ).all()
        
        if resolved_incidents:
            total_hours = 0
            count = 0
            for incident in resolved_incidents:
                if incident.incident_end and incident.incident_start:
                    delta = incident.incident_end - incident.incident_start
                    total_hours += delta.total_seconds() / 3600
                    count += 1
            if count > 0:
                avg_resolution_time_hours = round(total_hours / count, 2)
        
        # Top engineers (by incident count)
        top_engineers_query = db.query(
            models.Incident.on_call_engineer,
            func.count(models.Incident.id).label('count')
        )
        
        if date_from:
            top_engineers_query = top_engineers_query.filter(
                models.Incident.incident_start >= datetime.combine(date_from, datetime.min.time())
            )
        if date_to:
            top_engineers_query = top_engineers_query.filter(
                models.Incident.incident_start <= datetime.combine(date_to, datetime.max.time())
            )
        
        top_engineers_list = top_engineers_query.group_by(
            models.Incident.on_call_engineer
        ).order_by(func.count(models.Incident.id).desc()).limit(5).all()
        
        top_engineers = [{"engineer": engineer, "count": count} for engineer, count in top_engineers_list]
        
        # Engineer time totals (for payment calculation)
        engineer_time_query = db.query(models.Incident).filter(
            models.Incident.incident_end.isnot(None),
            models.Incident.incident_start.isnot(None)
        )
        
        if date_from:
            engineer_time_query = engineer_time_query.filter(
                models.Incident.incident_start >= datetime.combine(date_from, datetime.min.time())
            )
        if date_to:
            engineer_time_query = engineer_time_query.filter(
                models.Incident.incident_start <= datetime.combine(date_to, datetime.max.time())
            )
        
        engineer_incidents = engineer_time_query.all()
        
        # Calculate total time per engineer
        engineer_time_dict = {}
        for incident in engineer_incidents:
            engineer = incident.on_call_engineer
            if engineer not in engineer_time_dict:
                engineer_time_dict[engineer] = {"total_hours": 0, "total_incidents": 0}
            
            delta = incident.incident_end - incident.incident_start
            hours = delta.total_seconds() / 3600
            engineer_time_dict[engineer]["total_hours"] += hours
            engineer_time_dict[engineer]["total_incidents"] += 1
        
        # Convert to list and sort by total hours
        engineer_time_totals = [
            {
                "engineer": engineer,
                "total_hours": round(data["total_hours"], 2),
                "total_incidents": data["total_incidents"]
            }
            for engineer, data in engineer_time_dict.items()
        ]
        engineer_time_totals.sort(key=lambda x: x["total_hours"], reverse=True)
        
        # Incidents by day (for the last 30 days or filtered period)
        incidents_by_day = []
        if date_from and date_to:
            start_date = date_from
            end_date = date_to
        else:
            # Default to last 30 days
            end_date = date.today()
            start_date = end_date - timedelta(days=30)
        
        current_date = start_date
        while current_date <= end_date:
            day_start = datetime.combine(current_date, datetime.min.time())
            day_end = datetime.combine(current_date, datetime.max.time())
            
            count = query.filter(
                models.Incident.incident_start >= day_start,
                models.Incident.incident_start <= day_end
            ).count()
            
            incidents_by_day.append({
                "date": current_date.isoformat(),
                "count": count
            })
            
            current_date += timedelta(days=1)
        
        logger.info(f"Stats calculated: total={total_incidents}, pending={pending_review}")
        
        return {
            "total_incidents": total_incidents,
            "pending_review": pending_review,
            "by_priority": by_priority,
            "by_type": by_type,
            "avg_resolution_time_hours": avg_resolution_time_hours,
            "top_engineers": top_engineers,
            "incidents_by_day": incidents_by_day,
            "engineer_time_totals": engineer_time_totals
        }
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error getting stats: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error getting stats: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.get("/incidents/{incident_id}", response_model=schemas.IncidentResponse)
async def get_incident(
    incident_id: uuid.UUID,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get incident by ID"""
    try:
        logger.info(f"Getting incident {incident_id} by user: {current_user.username}")
        incident = db.query(models.Incident).filter(models.Incident.id == incident_id).first()
        if not incident:
            logger.warning(f"Incident {incident_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Incident not found"
            )
        logger.debug(f"Incident {incident_id} retrieved successfully")
        return incident
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error getting incident: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error getting incident: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.put("/incidents/{incident_id}", response_model=schemas.IncidentResponse)
async def update_incident(
    incident_id: uuid.UUID,
    incident_update: schemas.IncidentUpdate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update incident (only author or admin)"""
    try:
        logger.info(f"Updating incident {incident_id} by user: {current_user.username}")
        db_incident = db.query(models.Incident).filter(models.Incident.id == incident_id).first()
        if not db_incident:
            logger.warning(f"Incident {incident_id} not found for update")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Incident not found"
            )
        
        # Check permissions: only author or admin can edit
        if current_user.role != "admin" and db_incident.on_call_engineer != current_user.username:
            logger.warning(f"User {current_user.username} attempted to update incident {incident_id} without permission")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not authorized to edit this incident"
            )
        
        # Store old values for audit log
        old_values = {
            "incident_start": str(db_incident.incident_start),
            "incident_end": str(db_incident.incident_end) if db_incident.incident_end else None,
            "incident_type": db_incident.incident_type,
            "severity": db_incident.severity,
            "description": db_incident.description,
            "resolution": db_incident.resolution
        }
        
        # Update fields
        update_data = incident_update.model_dump(exclude_unset=True, mode='json')
        for field, value in update_data.items():
            setattr(db_incident, field, value)
        
        db.commit()
        db.refresh(db_incident)
        
        logger.info(f"Incident {incident_id} updated successfully")
        
        # Create audit log entry
        try:
            auth.create_audit_log(db, incident_id, "UPDATE", current_user.username, old_values, update_data)
        except Exception as audit_error:
            logger.error(f"Failed to create audit log: {str(audit_error)}")
            # Don't fail the request if audit log fails
        
        return db_incident
    except HTTPException:
        raise
    except IntegrityError as e:
        logger.error(f"Database integrity error updating incident: {str(e)}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Database integrity error"
        )
    except SQLAlchemyError as e:
        logger.error(f"Database error updating incident: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error updating incident: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.patch("/incidents/{incident_id}/review", response_model=schemas.IncidentResponse)
async def review_incident(
    incident_id: uuid.UUID,
    review: schemas.IncidentReview,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Manager review incident"""
    try:
        logger.info(f"Reviewing incident {incident_id} by user: {current_user.username}, reviewed: {review.reviewed}")
        # Check if user is manager or admin
        if current_user.role not in ["manager", "admin"]:
            logger.warning(f"User {current_user.username} attempted to review incident without permission")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only managers and admins can review incidents"
            )
        
        db_incident = db.query(models.Incident).filter(models.Incident.id == incident_id).first()
        if not db_incident:
            logger.warning(f"Incident {incident_id} not found for review")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Incident not found"
            )
        
        # Store old values
        old_values = {
            "manager_reviewed": db_incident.manager_reviewed,
            "manager_reviewed_at": str(db_incident.manager_reviewed_at) if db_incident.manager_reviewed_at else None,
            "manager_name": db_incident.manager_name
        }
        
        # Update review status
        db_incident.manager_reviewed = review.reviewed
        if review.reviewed:
            db_incident.manager_reviewed_at = datetime.utcnow()
            db_incident.manager_name = current_user.username
        else:
            db_incident.manager_reviewed_at = None
            db_incident.manager_name = None
        
        db.commit()
        db.refresh(db_incident)
        
        logger.info(f"Incident {incident_id} review status updated")
        
        # Create audit log entry
        try:
            new_values = {
                "manager_reviewed": review.reviewed,
                "manager_reviewed_at": str(db_incident.manager_reviewed_at) if db_incident.manager_reviewed_at else None,
                "manager_name": db_incident.manager_name
            }
            auth.create_audit_log(db, incident_id, "REVIEW", current_user.username, old_values, new_values)
        except Exception as audit_error:
            logger.error(f"Failed to create audit log: {str(audit_error)}")
            # Don't fail the request if audit log fails
        
        return db_incident
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error reviewing incident: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error reviewing incident: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.delete("/incidents/{incident_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_incident(
    incident_id: uuid.UUID,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete incident (admin only)"""
    try:
        logger.info(f"Deleting incident {incident_id} by user: {current_user.username}")
        if current_user.role != "admin":
            logger.warning(f"User {current_user.username} attempted to delete incident without admin permission")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only admins can delete incidents"
            )
        
        db_incident = db.query(models.Incident).filter(models.Incident.id == incident_id).first()
        if not db_incident:
            logger.warning(f"Incident {incident_id} not found for deletion")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Incident not found"
            )
        
        # Create audit log entry before deletion
        try:
            auth.create_audit_log(
                db, 
                incident_id, 
                "DELETE", 
                current_user.username, 
                {
                    "id": str(db_incident.id),
                    "on_call_engineer": db_incident.on_call_engineer,
                    "incident_type": db_incident.incident_type
                },
                None
            )
        except Exception as audit_error:
            logger.error(f"Failed to create audit log: {str(audit_error)}")
            # Continue with deletion even if audit log fails
        
        db.delete(db_incident)
        db.commit()
        
        logger.info(f"Incident {incident_id} deleted successfully")
        return None
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error deleting incident: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error deleting incident: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.get("/incidents/{incident_id}/audit", response_model=List[schemas.AuditLogResponse])
async def get_incident_audit_log(
    incident_id: uuid.UUID,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get audit log for an incident"""
    try:
        logger.info(f"Getting audit log for incident {incident_id} by user: {current_user.username}")
        # Check if incident exists
        incident = db.query(models.Incident).filter(models.Incident.id == incident_id).first()
        if not incident:
            logger.warning(f"Incident {incident_id} not found when requesting audit log")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Incident not found"
            )
        
        audit_logs = db.query(models.IncidentAuditLog).filter(
            models.IncidentAuditLog.incident_id == incident_id
        ).order_by(models.IncidentAuditLog.changed_at.desc()).all()
        
        logger.debug(f"Returning {len(audit_logs)} audit log entries")
        return audit_logs
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error getting audit log: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error getting audit log: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.post("/auth/login", response_model=schemas.TokenResponse)
async def login(credentials: schemas.LoginRequest, db: Session = Depends(get_db)):
    """Login and get authentication token"""
    try:
        logger.info(f"Login attempt for user: {credentials.username}")
        
        # First check if user exists
        user = db.query(models.User).filter(models.User.username == credentials.username).first()
        if not user:
            logger.warning(f"Login attempt for non-existent user: {credentials.username}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password"
            )
        
        # Check if user is approved BEFORE checking password (to give better error message)
        if not user.approved and user.role != 'admin':
            # Still verify password to avoid revealing if username exists
            authenticated_user = auth.authenticate_user(db, credentials.username, credentials.password)
            if authenticated_user:
                # Password is correct but user is not approved
                logger.warning(f"Login attempt by unapproved user with correct password: {user.username}")
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Вашият акаунт чака одобрение от администратор. Моля изчакайте одобрение преди да влезете."
                )
            else:
                # Password is wrong, but don't reveal that user exists
                logger.warning(f"Failed login attempt for unapproved user: {credentials.username}")
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Incorrect username or password"
                )
        
        # User is approved (or is admin), now authenticate
        authenticated_user = auth.authenticate_user(db, credentials.username, credentials.password)
        if not authenticated_user:
            logger.warning(f"Failed login attempt for user: {credentials.username}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password"
            )
        
        # Reload user from current session to ensure all fields are accessible
        user = db.query(models.User).filter(models.User.username == authenticated_user.username).first()
        if not user:
            logger.error(f"User {authenticated_user.username} not found after authentication")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error"
            )
        
        token = auth.create_access_token(user)
        logger.info(f"Successful login for user: {user.username} ({user.role})")
        return {"access_token": token, "token_type": "bearer", "user": user_to_response(user)}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error during login: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Login error"
        )


@app.post("/auth/register", response_model=schemas.UserResponse, status_code=status.HTTP_201_CREATED)
async def register(user_data: schemas.UserCreate, db: Session = Depends(get_db)):
    """Register a new user"""
    try:
        logger.info(f"Registration attempt for user: {user_data.username}")
        
        # Check if username already exists
        existing_user = db.query(models.User).filter(models.User.username == user_data.username).first()
        if existing_user:
            logger.warning(f"Registration failed: username {user_data.username} already exists")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username already exists"
            )
        
        # Check if email already exists
        existing_email = db.query(models.User).filter(models.User.email == user_data.email).first()
        if existing_email:
            logger.warning(f"Registration failed: email {user_data.email} already exists")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already exists"
            )
        
        # Create new user (not approved by default)
        hashed_password = auth.get_password_hash(user_data.password)
        logger.debug(f"Hashing password for user {user_data.username}, hash length: {len(hashed_password)}")
        new_user = models.User(
            username=user_data.username,
            email=user_data.email,
            first_name=user_data.first_name,
            last_name=user_data.last_name,
            role=user_data.role,
            password_hash=hashed_password,
            approved=False  # Requires admin approval
        )
        
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        
        logger.info(f"User registered successfully: {new_user.username} ({new_user.role})")
        return user_to_response(new_user)
    except HTTPException:
        raise
    except IntegrityError as e:
        logger.error(f"Database integrity error during registration: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User registration failed due to database constraint"
        )
    except SQLAlchemyError as e:
        logger.error(f"Database error during registration: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error during registration: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Registration error"
        )


@app.get("/auth/me", response_model=schemas.UserResponse)
async def get_current_user_info(current_user: models.User = Depends(get_current_user)):
    """Get current user information"""
    return user_to_response(current_user)


@app.get("/users/engineers", response_model=List[schemas.UserResponse])
async def get_engineers(
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get list of all approved engineers"""
    try:
        logger.info(f"Getting engineers list for user: {current_user.username}")
        engineers = db.query(models.User).filter(
            models.User.role == 'engineer',
            models.User.approved == True
        ).all()
        logger.info(f"Found {len(engineers)} approved engineers")
        return [user_to_response(eng) for eng in engineers]
    except SQLAlchemyError as e:
        logger.error(f"Database error getting engineers: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error getting engineers: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.get("/users/pending", response_model=List[schemas.UserResponse])
async def get_pending_users(
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get list of users pending approval (admin only)"""
    try:
        if current_user.role != 'admin':
            logger.warning(f"Non-admin user {current_user.username} attempted to access pending users")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only administrators can view pending users"
            )
        
        logger.info(f"Getting pending users list for admin: {current_user.username}")
        pending_users = db.query(models.User).filter(models.User.approved == False).order_by(models.User.created_at.desc()).all()
        logger.info(f"Found {len(pending_users)} pending users")
        return pending_users
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error getting pending users: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error getting pending users: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.get("/users/all", response_model=List[schemas.UserResponse])
async def get_all_users(
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get list of all users (admin only)"""
    try:
        if current_user.role != 'admin':
            logger.warning(f"Non-admin user {current_user.username} attempted to access all users")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only administrators can view all users"
            )
        
        logger.info(f"Getting all users list for admin: {current_user.username}")
        users = db.query(models.User).order_by(models.User.created_at.desc()).all()
        logger.info(f"Found {len(users)} users")
        return [user_to_response(u) for u in users]
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error getting all users: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error getting all users: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.get("/users/{username}", response_model=schemas.UserResponse)
async def get_user_by_username(
    username: str,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get user details by username (accessible to all authenticated users)"""
    try:
        logger.info(f"Getting user details for username: {username} (requested by: {current_user.username})")
        user = db.query(models.User).filter(models.User.username == username).first()
        
        if not user:
            logger.warning(f"User {username} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        # Only return approved users (unless admin is viewing)
        if not user.approved and current_user.role != 'admin':
            logger.warning(f"Attempt to view unapproved user {username} by {current_user.username}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        logger.info(f"Found user: {username}")
        return user_to_response(user)
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error getting user: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error getting user: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.patch("/users/{user_id}/approve")
async def approve_user(
    user_id: uuid.UUID,
    approval: schemas.UserApprovalRequest,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Approve or reject a user (admin only). If rejected, user is deleted from database."""
    try:
        if current_user.role != 'admin':
            logger.warning(f"Non-admin user {current_user.username} attempted to approve user")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only administrators can approve users"
            )
        
        user = db.query(models.User).filter(models.User.id == user_id).first()
        if not user:
            logger.warning(f"User {user_id} not found for approval")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        if approval.approved:
            # Approve user
            user.approved = True
            db.commit()
            db.refresh(user)
            logger.info(f"User {user.username} approved by admin {current_user.username}")
            return user_to_response(user)
        else:
            # Reject user - delete from database
            username = user.username
            db.delete(user)
            db.commit()
            logger.info(f"User {username} rejected and deleted by admin {current_user.username}")
            # Return 204 No Content for deletion
            from fastapi import Response
            return Response(status_code=status.HTTP_204_NO_CONTENT)
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error approving user: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error approving user: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.put("/users/{user_id}", response_model=schemas.UserResponse)
async def update_user(
    user_id: uuid.UUID,
    user_update: schemas.UserUpdate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update a user (admin only)"""
    try:
        if current_user.role != 'admin':
            logger.warning(f"Non-admin user {current_user.username} attempted to update user")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only administrators can update users"
            )
        
        user = db.query(models.User).filter(models.User.id == user_id).first()
        if not user:
            logger.warning(f"User {user_id} not found for update")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        # Update fields if provided
        update_data = user_update.model_dump(exclude_unset=True)
        
        if 'username' in update_data and update_data['username']:
            # Check if username already exists (excluding current user)
            existing = db.query(models.User).filter(
                models.User.username == update_data['username'],
                models.User.id != user_id
            ).first()
            if existing:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Username already exists"
                )
            user.username = update_data['username']
        
        if 'email' in update_data and update_data['email']:
            # Check if email already exists (excluding current user)
            existing = db.query(models.User).filter(
                models.User.email == update_data['email'],
                models.User.id != user_id
            ).first()
            if existing:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Email already exists"
                )
            user.email = update_data['email']
        
        if 'first_name' in update_data:
            user.first_name = update_data['first_name']
        
        if 'last_name' in update_data:
            user.last_name = update_data['last_name']
        
        if 'role' in update_data and update_data['role']:
            user.role = update_data['role']
        
        if 'approved' in update_data:
            user.approved = update_data['approved']
        
        if 'password' in update_data and update_data['password']:
            user.password_hash = auth.get_password_hash(update_data['password'])
        
        db.commit()
        db.refresh(user)
        
        logger.info(f"User {user.username} updated by admin {current_user.username}")
        return user_to_response(user)
    except HTTPException:
        raise
    except IntegrityError as e:
        logger.error(f"Database integrity error updating user: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User update failed due to database constraint"
        )
    except SQLAlchemyError as e:
        logger.error(f"Database error updating user: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error updating user: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(
    user_id: uuid.UUID,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a user (admin only)"""
    try:
        if current_user.role != 'admin':
            logger.warning(f"Non-admin user {current_user.username} attempted to delete user")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only administrators can delete users"
            )
        
        user = db.query(models.User).filter(models.User.id == user_id).first()
        if not user:
            logger.warning(f"User {user_id} not found for deletion")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        # Prevent deleting yourself
        if user.id == current_user.id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="You cannot delete your own account"
            )
        
        username = user.username
        db.delete(user)
        db.commit()
        
        logger.info(f"User {username} deleted by admin {current_user.username}")
        return None
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error deleting user: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error deleting user: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.post("/auth/password-reset-request", status_code=status.HTTP_201_CREATED)
async def create_password_reset_request(
    request_data: schemas.PasswordResetRequestCreate,
    db: Session = Depends(get_db)
):
    """Create a password reset request (no auth required)"""
    try:
        logger.info(f"Password reset request for email: {request_data.email}")
        
        # Find user by email
        user = db.query(models.User).filter(models.User.email == request_data.email).first()
        if not user:
            # Don't reveal if email exists or not (security best practice)
            logger.warning(f"Password reset requested for non-existent email: {request_data.email}")
            return {"message": "If the email exists, a reset request has been created"}
        
        # Check if there's already a pending request
        existing_request = db.query(models.PasswordResetRequest).filter(
            models.PasswordResetRequest.user_id == user.id,
            models.PasswordResetRequest.status == "pending"
        ).first()
        
        if existing_request:
            logger.info(f"Pending reset request already exists for user: {user.username}")
            return {"message": "A password reset request is already pending approval"}
        
        # Hash the new password
        hashed_password = auth.get_password_hash(request_data.new_password)
        
        # Create reset request
        reset_request = models.PasswordResetRequest(
            user_id=user.id,
            new_password_hash=hashed_password,
            status="pending"
        )
        
        db.add(reset_request)
        db.commit()
        db.refresh(reset_request)
        
        logger.info(f"Password reset request created for user: {user.username} (ID: {reset_request.id})")
        return {"message": "Password reset request has been submitted and is pending admin approval"}
    except SQLAlchemyError as e:
        logger.error(f"Database error creating password reset request: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error creating password reset request: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.get("/password-reset-requests", response_model=List[schemas.PasswordResetRequestResponse])
async def get_password_reset_requests(
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get list of password reset requests (admin only)"""
    try:
        if current_user.role != 'admin':
            logger.warning(f"Non-admin user {current_user.username} attempted to access password reset requests")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only administrators can view password reset requests"
            )
        
        logger.info(f"Getting password reset requests for admin: {current_user.username}")
        requests = db.query(models.PasswordResetRequest).order_by(
            models.PasswordResetRequest.requested_at.desc()
        ).all()
        
        # Build response with user info
        result = []
        for req in requests:
            user = db.query(models.User).filter(models.User.id == req.user_id).first()
            if user:
                result.append({
                    "id": req.id,
                    "user_id": req.user_id,
                    "username": user.username,
                    "email": user.email,
                    "status": req.status,
                    "requested_at": req.requested_at,
                    "reviewed_at": req.reviewed_at,
                    "reviewed_by": req.reviewed_by
                })
        
        logger.info(f"Found {len(result)} password reset requests")
        return result
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error getting password reset requests: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error getting password reset requests: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@app.patch("/password-reset-requests/{request_id}/review", response_model=schemas.PasswordResetRequestResponse)
async def review_password_reset_request(
    request_id: uuid.UUID,
    review: schemas.PasswordResetRequestReview,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Approve or reject a password reset request (admin only)"""
    try:
        if current_user.role != 'admin':
            logger.warning(f"Non-admin user {current_user.username} attempted to review password reset request")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only administrators can review password reset requests"
            )
        
        reset_request = db.query(models.PasswordResetRequest).filter(
            models.PasswordResetRequest.id == request_id
        ).first()
        
        if not reset_request:
            logger.warning(f"Password reset request {request_id} not found")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Password reset request not found"
            )
        
        if reset_request.status != "pending":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Request has already been {reset_request.status}"
            )
        
        if review.approved:
            # Update user's password
            user = db.query(models.User).filter(models.User.id == reset_request.user_id).first()
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="User not found"
                )
            
            user.password_hash = reset_request.new_password_hash
            reset_request.status = "approved"
            logger.info(f"Password reset approved for user: {user.username} by admin: {current_user.username}")
        else:
            reset_request.status = "rejected"
            logger.info(f"Password reset rejected for request {request_id} by admin: {current_user.username}")
        
        reset_request.reviewed_at = datetime.utcnow()
        reset_request.reviewed_by = current_user.username
        
        db.commit()
        db.refresh(reset_request)
        
        # Build response
        user = db.query(models.User).filter(models.User.id == reset_request.user_id).first()
        return {
            "id": reset_request.id,
            "user_id": reset_request.user_id,
            "username": user.username if user else "Unknown",
            "email": user.email if user else "Unknown",
            "status": reset_request.status,
            "requested_at": reset_request.requested_at,
            "reviewed_at": reset_request.reviewed_at,
            "reviewed_by": reset_request.reviewed_by
        }
    except HTTPException:
        raise
    except SQLAlchemyError as e:
        logger.error(f"Database error reviewing password reset request: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database error"
        )
    except Exception as e:
        logger.error(f"Unexpected error reviewing password reset request: {str(e)}\n{traceback.format_exc()}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )

