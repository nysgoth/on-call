#!/usr/bin/env python3
"""
Test login functionality
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.database import SessionLocal
from app import models, schemas
from app.auth import authenticate_user, get_password_hash, verify_password

db = SessionLocal()

try:
    print("Testing login functionality...")
    
    # Test user
    username = "engineer1"
    password = "engineer123"
    
    print(f"\n1. Testing password verification...")
    user = db.query(models.User).filter(models.User.username == username).first()
    if user:
        print(f"   User found: {user.username}")
        print(f"   Has password hash: {bool(user.password_hash)}")
        print(f"   Approved: {user.approved}")
        print(f"   First name: {getattr(user, 'first_name', None)}")
        print(f"   Last name: {getattr(user, 'last_name', None)}")
        
        if user.password_hash:
            is_valid = verify_password(password, user.password_hash)
            print(f"   Password verification: {is_valid}")
    
    print(f"\n2. Testing authenticate_user...")
    auth_user = authenticate_user(db, username, password)
    if auth_user:
        print(f"   ✅ Authentication successful: {auth_user.username}")
    else:
        print(f"   ❌ Authentication failed")
    
    print(f"\n3. Testing user_to_response conversion...")
    if auth_user:
        try:
            response = schemas.UserResponse(
                id=auth_user.id,
                username=auth_user.username,
                email=auth_user.email,
                first_name=getattr(auth_user, 'first_name', None),
                last_name=getattr(auth_user, 'last_name', None),
                role=auth_user.role,
                approved=auth_user.approved,
                created_at=auth_user.created_at
            )
            print(f"   ✅ Conversion successful: {response.username} - {response.first_name} {response.last_name}")
        except Exception as e:
            print(f"   ❌ Conversion failed: {e}")
            import traceback
            traceback.print_exc()
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
finally:
    db.close()

