#!/usr/bin/env python3
"""
Script to update user names
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.database import SessionLocal
from app import models

# Users to update with names
users_to_update = {
    "hhristov": {"first_name": "Hristo", "last_name": "Hristov"},
    "bdelev": {"first_name": "Boyan", "last_name": "Delev"},
    "bkalchev": {"first_name": "Bozhidar", "last_name": "Kalchev"},
    "znikolov": {"first_name": "Zefir", "last_name": "Nikolov"},
    "smladenov": {"first_name": "Svilen", "last_name": "Mladenov"},
    "engineer1": {"first_name": "Ivan", "last_name": "Petrov"},
    "manager1": {"first_name": "Maria", "last_name": "Georgieva"},
    "admin1": {"first_name": "Dimitar", "last_name": "Ivanov"},
}

db = SessionLocal()

try:
    print("Updating user names...")
    
    for username, names in users_to_update.items():
        user = db.query(models.User).filter(models.User.username == username).first()
        if user:
            user.first_name = names["first_name"]
            user.last_name = names["last_name"]
            print(f"✅ Updated {username}: {names['first_name']} {names['last_name']}")
        else:
            print(f"⏭️  User not found: {username}")
    
    db.commit()
    print("\n✨ All user names updated successfully!")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
    db.rollback()
finally:
    db.close()

