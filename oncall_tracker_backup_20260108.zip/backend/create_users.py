#!/usr/bin/env python3
"""
Script to create specific users
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.database import SessionLocal
from app import models
from app.auth import get_password_hash

# Users to create
users_to_create = [
    # Demo users
    {
        "username": "engineer1",
        "email": "engineer1@company.com",
        "first_name": "Ivan",
        "last_name": "Petrov",
        "role": "engineer",
        "password": "engineer123",
        "approved": True
    },
    {
        "username": "manager1",
        "email": "manager1@company.com",
        "first_name": "Maria",
        "last_name": "Georgieva",
        "role": "manager",
        "password": "manager123",
        "approved": True
    },
    {
        "username": "admin1",
        "email": "admin1@company.com",
        "first_name": "Dimitar",
        "last_name": "Ivanov",
        "role": "admin",
        "password": "admin123",
        "approved": True
    },
    # Real users
    {
        "username": "hhristov",
        "email": "hhristov@dskbank.bg",
        "first_name": "Hristo",
        "last_name": "Hristov",
        "role": "engineer",
        "password": "123456",
        "approved": True
    },
    {
        "username": "bdelev",
        "email": "bdelev@dskbank.bg",
        "first_name": "Boyan",
        "last_name": "Delev",
        "role": "engineer",
        "password": "123456",
        "approved": True
    },
    {
        "username": "bkalchev",
        "email": "bkalchev@dskbank.bg",
        "first_name": "Bozhidar",
        "last_name": "Kalchev",
        "role": "engineer",
        "password": "123456",
        "approved": True
    },
    {
        "username": "znikolov",
        "email": "znikolov@dskbank.bg",
        "first_name": "Zefir",
        "last_name": "Nikolov",
        "role": "engineer",
        "password": "123456",
        "approved": True
    },
    {
        "username": "smladenov",
        "email": "smladenov@dskbank.bg",
        "first_name": "Svilen",
        "last_name": "Mladenov",
        "role": "engineer",
        "password": "123456",
        "approved": True
    }
]

db = SessionLocal()

try:
    print("Creating users...")
    for user_data in users_to_create:
        existing_user = db.query(models.User).filter(models.User.username == user_data["username"]).first()
        if not existing_user:
            user = models.User(
                username=user_data["username"],
                email=user_data["email"],
                first_name=user_data.get("first_name"),
                last_name=user_data.get("last_name"),
                role=user_data["role"],
                password_hash=get_password_hash(user_data["password"]),
                approved=user_data.get("approved", True)
            )
            db.add(user)
            print(f"✅ Created user: {user_data['username']} ({user_data['role']}) - {user_data['email']}")
        else:
            print(f"⏭️  User already exists: {user_data['username']}")
    
    db.commit()
    print("\n✨ All users created successfully!")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
    db.rollback()
finally:
    db.close()

