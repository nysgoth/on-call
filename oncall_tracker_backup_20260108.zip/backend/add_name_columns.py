#!/usr/bin/env python3
"""
Script to add first_name and last_name columns to users table
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.database import engine
from sqlalchemy import text

try:
    print("Adding first_name and last_name columns to users table...")
    
    with engine.connect() as conn:
        # Check if columns exist
        result = conn.execute(text("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name='users' AND column_name IN ('first_name', 'last_name')
        """))
        existing_columns = [row[0] for row in result]
        
        # Add first_name column if it doesn't exist
        if 'first_name' not in existing_columns:
            conn.execute(text("ALTER TABLE users ADD COLUMN first_name VARCHAR(255)"))
            conn.commit()
            print("✅ Added first_name column")
        else:
            print("⏭️  first_name column already exists")
        
        # Add last_name column if it doesn't exist
        if 'last_name' not in existing_columns:
            conn.execute(text("ALTER TABLE users ADD COLUMN last_name VARCHAR(255)"))
            conn.commit()
            print("✅ Added last_name column")
        else:
            print("⏭️  last_name column already exists")
    
    print("\n✨ Columns added successfully!")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()

